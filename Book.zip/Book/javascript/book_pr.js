
document.addEventListener('DOMContentLoaded', function () {
    const menuButton = document.querySelector('.slicknav-btn');
    const menu = document.querySelector('.slicknav-nav');
    const submenuButtons = document.querySelectorAll('.slicknav-nav > li > a');

    menuButton.addEventListener('click', function () {
        menu.classList.toggle('show');
    });

    submenuButtons.forEach(button => {
        button.addEventListener('click', function (event) {
            const submenu = this.nextElementSibling;
            if (submenu) {
                submenu.classList.toggle('show');
                event.preventDefault();
            }
        });
    });
});
